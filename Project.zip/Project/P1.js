//opening image and difficulty choise
var game=document.getElementById("A");
var ctx = game.getContext("2d");
var img_opening = new Image();
img_opening.src="opening.jpg";
img_opening.onload = function () {
  ctx.drawImage(img_opening, 0,150,800,550);
  ctx.fillStyle="red";
  ctx.font = "italic 30px Arial";
  ctx.strokeStyle="black";
  ctx.lineWidth = 3;
  ctx.strokeText("Normal", 70, 450);
  ctx.fillText("Normal",70,450);
  ctx.strokeText("Hard",70,500);
  ctx.fillText("Hard",70,500);
  ctx.font = "italic 80px Arial";
  ctx.strokeText("Dragon May Cry",70,220);
  ctx.fillText("Dragon May Cry",70,240);
  ctx.stroke();
  ctx.lineWidth = 2;
  ctx.font = "italic 20px Arial";
  ctx.strokeText("1. Avoid all enemies.", 70,730);
  ctx.strokeText("2. Hide in the jungles to become invisible.", 70,760);
  ctx.strokeText("3. Reach the castle before time ends.", 70, 790);
}

function selectdif() {
  var normal_x=75;
  var normal_y=427;
  var hard_x=75;
  var hard_y=475;
  var x = event.offsetX;
  var y = event.offsetY;

  if(x > normal_x && x < normal_x+90 && y > normal_y && y < normal_y+23) {
    normalmode();
  }
  else if(x > hard_x && x < hard_x+60 && y > hard_y && y < hard_y+23) {
    hardmode();
  }
}

function xycor(event) {
  var xPosLabel = document.getElementById("xout");
  var yPosLabel = document.getElementById("yout");

  xPosLabel.innerHTML = event.offsetX;
  yPosLabel.innerHTML = event.offsetY;
}

function normalmode() {
  ctx.fillStyle="black";
  ctx.font = "italic 30px Arial";
  let time = 60;
  let timer = setInterval(myTimer, 1000);
  function myTimer() {
    ctx.clearRect(710,5,80,40);
    time = (time - 1);
    ctx.fillText(time, 750,30);
    ctx.strokeText(time,750,30);
    if(time === 0) {
    gameover();
    }
  }
//jungle & castle
  var junglearray = [];
  var p_j_distance=0;
  var p_j_array=[];
  var x_jungle=100+Math.random()*600;
  var y_jungle=100+Math.random()*480;
  function adddis(number) {
    p_j_distance=Math.sqrt(Math.pow((playerX+40)-(x_jungle+35),2)+Math.pow((playerY+40)-(y_jungle+35),2))
    for(var i=0;i<number;i++) {
      p_j_array.push(p_j_distance);
    }
  }
  function Jungle(x_jungle, y_jungle) {
    this.x=x_jungle;
    this.y=y_jungle;
  }
  function addjungle(number) {
    for(var i=0;i<number;i++) {
      x_jungle=100+Math.random()*600;
      y_jungle=100+Math.random()*480;
      junglearray.push(new Jungle(x_jungle,y_jungle))
      }
    }
  function drawjungle(number) {
    for(var i=0;i<number;i++) {
      ctx.drawImage(img_jungle,junglearray[i].x,junglearray[i].y,70,70);
    }
  }
  ctx.clearRect(0,0,800,800);
  let img_jungle = new Image();
  img_jungle.src="jungle1.PNG";
  img_jungle.onload = function () {
    addjungle(5);
    drawjungle(5);
  }
  let img_castle = new Image();
  img_castle.src="castle.PNG";
  img_castle.onload = function () {
    ctx.drawImage(img_castle,250,700,165,100);
  }

//enemy
  var xposition=0;
  var yposition=0;
  var xspeed=40;
  var yspeed=40;
  var random=0;
  var enemyarray = [];
  function Enemy(xposition, yposition) {
    this.x=xposition;
    this.y=yposition;
  }
  function addEnemies(number){
    for(var i=0;i<number;i++) {
      xposition=50+Math.random()*700;
      yposition=150+Math.random()*500;
      enemyarray.push(new Enemy(xposition, yposition));
    }
  }
  function check(i) {
    playerX;
    playerY;
    p_j_distance=Math.sqrt(Math.pow((playerX+40)-(junglearray[i].x+35),2)+Math.pow((playerY+40)-(junglearray[i].y+35),2));
    if(p_j_distance < 40)
      return false;
    else {return true;}
  }
  var p_e_distance=0;
  let img_enemy = new Image();
  let moving;
  let sW=270;
  img_enemy.src="enemy.PNG";
  img_enemy.onload = function () {
    addEnemies(5);
    adddis(5);
    moving=setInterval(function(){
    for(var i=0;i<enemyarray.length;i++) {
     random = Math.random();
     if(random<0.25) {
       ctx.clearRect(enemyarray[i].x, enemyarray[i].y,70,70);
       enemyarray[i].x += xspeed;
       enemyarray[i].y += yspeed;
       if(enemyarray[i].x > 720)
         enemyarray[i].x -= xspeed;
       if(enemyarray[i].y > 600)
         enemyarray[i].y -= yspeed;
     }
     else if(random<0.5) {
       ctx.clearRect(enemyarray[i].x,enemyarray[i].y,70,70);
       enemyarray[i].x += xspeed;
       enemyarray[i].y -= yspeed;
       if(enemyarray[i].x > 720)
         enemyarray[i].x -= xspeed;
       if(enemyarray[i].y < 0)
         enemyarray[i].y += yspeed;
     }
     else if(random<0.75) {
       ctx.clearRect(enemyarray[i].x,enemyarray[i].y,70,70);
       enemyarray[i].x -= xspeed;
       enemyarray[i].y += yspeed;
       if(enemyarray[i].x < 0)
         enemyarray[i].x += xspeed;
       if(enemyarray[i].y > 600)
         enemyarray[i].y -= yspeed;
      }
     else {
       ctx.clearRect(enemyarray[i].x,enemyarray[i].y,70,70);
       enemyarray[i].x -= xspeed;
       enemyarray[i].y -= yspeed;
       if(enemyarray[i].x < 0)
         enemyarray[i].x += xspeed;
       if(enemyarray[i].y < 0)
         enemyarray[i].y += yspeed;
      }
     drawjungle(5);
     draw(enemyarray[i].x,enemyarray[i].y);
     p_j_distance=Math.sqrt(Math.pow((playerX+40)-(x_jungle+35),2)+Math.pow((playerY+40)-(y_jungle+35),2));
     p_e_distance=Math.sqrt(Math.pow((playerX+40)-(enemyarray[i].x+35),2)+Math.pow((playerY+40)-(enemyarray[i].y+35),2));
     if(p_e_distance < 100) {
       var result=true;
      for(var i=0;i<junglearray.length;i++) {
        result = result && check(i);
      }
      if(result) {
       gameover();
     }
     }
 }},435);
 }

  function draw(xposition,yposition) {
      ctx.clearRect(xposition,yposition,70,70);
      ctx.drawImage(img_enemy,sW,700,266,260,xposition,yposition,70,70,);
  }

  //Player
  var check_gameover=false;
  var img_player = new Image();
  var playerxspeed=20;
  var playeryspeed=20;
  var playerX=300;
  var playerY=10;
  var p_e_distance=0;
  img_player.src="player.PNG"
  img_player.onload=function () {
    ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
  }
  addEventListener("keydown", function(event) {
    if(event.keyCode == 38 && playerY > 0) {
      if(check_gameover) {
        playerY -= 0;
      }
      else {
      ctx.clearRect(playerX,playerY,80,80);
      playerY -= playeryspeed;
      drawjungle(5);
      ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
      }
    }
    if(playerX>250 && playerX<415 && playerY > 650) {
      wincondition();
    }
  })

  addEventListener("keydown", function(event) {
    if(event.keyCode == 40 && playerY < 720) {
      if(check_gameover) {
        playerY += 0;
      }
      else {
      ctx.clearRect(playerX,playerY,80,80);
      playerY += playeryspeed;
      drawjungle(5);
      ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
      }
    }
    if(playerX>250 && playerX<415 && playerY > 650) {
      wincondition();
    }
  })

  addEventListener("keydown", function(event) {
    if(event.keyCode == 39 && playerX < 720) {
      if(check_gameover) {
        playerX += 0;
      }
      else {
      ctx.clearRect(playerX,playerY,80,80);
      playerX += playerxspeed;
      drawjungle(5);
      ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
      }
    }
    if(playerX>250 && playerX<415 && playerY > 650) {
      wincondition();
    }
  })

  addEventListener("keydown", function(event) {
    if(event.keyCode == 37 && playerX > 0) {
      if(check_gameover) {
        playerX -= 0;
      }
      else {
      ctx.clearRect(playerX,playerY,80,80);
      playerX -= playerxspeed;
      drawjungle(5);
      ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
      }
    }
    if(playerX>250 && playerX<415 && playerY > 650) {
      wincondition();
    }
  })
  function wincondition() {
    clearInterval(timer);
    clearInterval(moving);
    ctx.clearRect(xposition,yposition,80,80);
    ctx.clearRect(playerX,playerY,120,80);
    ctx.clearRect(710,5,80,40);

    ctx.clearRect(0,0,800,800);
    ctx.fillStyle="red";
    ctx.font = "italic 110px Arial";
    ctx.strokeStyle="black";
    ctx.lineWidth = 7;
    ctx.strokeText("YOU WIN!", 100, 380);
    ctx.fillText("YOU WIN!",100,380);
  }
  function gameover() {
    clearInterval(timer);
    clearInterval(moving);

    ctx.clearRect(0,0,800,800);
    ctx.fillStyle="red";
    ctx.font = "italic 110px Arial";
    ctx.strokeStyle="black";
    ctx.lineWidth = 7;
    ctx.strokeText("GAME OVER!", 70, 380);
    ctx.fillText("GAME OVER!",70,380);
    check_gameover=true;
  }
}

function hardmode() {
  ctx.fillStyle="black";
  ctx.font = "italic 30px Arial";
  let time = 45;
  let timer = setInterval(myTimer, 1000);
  function myTimer() {
    ctx.clearRect(710,5,80,40);
    time = (time - 1);
    ctx.fillText(time, 750,30);
    ctx.strokeText(time,750,30);
    if(time === 0) {
    gameover();
    }
  }
//jungle & castle
  var junglearray = [];
  var p_j_distance=0;
  var p_j_array=[];
  var x_jungle=100+Math.random()*600;
  var y_jungle=100+Math.random()*480;
  function Jungle(x_jungle, y_jungle) {
    this.x=x_jungle;
    this.y=y_jungle;
  }
  function addjungle(number) {
    for(var i=0;i<number;i++) {
      x_jungle=100+Math.random()*600;
      y_jungle=100+Math.random()*480;
      junglearray.push(new Jungle(x_jungle,y_jungle))
      }
    }
  function drawjungle(number) {
    for(var i=0;i<number;i++) {
      ctx.drawImage(img_jungle,junglearray[i].x,junglearray[i].y,70,70);
    }
  }
  ctx.clearRect(0,0,800,800);
  let img_jungle = new Image();
  img_jungle.src="jungle1.PNG";
  img_jungle.onload = function () {
    addjungle(8);
    drawjungle(8);
  }
  let img_castle = new Image();
  img_castle.src="castle.PNG";
  img_castle.onload = function () {
    ctx.drawImage(img_castle,250,700,165,100);
  }

//enemy
  var xposition=0;
  var yposition=0;
  var xspeed=40;
  var yspeed=40;
  var random=0;
  var enemyarray = [];
  function Enemy(xposition, yposition) {
    this.x=xposition;
    this.y=yposition;
  }
  function addEnemies(number){
    for(var i=0;i<number;i++) {
      xposition=50+Math.random()*700;
      yposition=200+Math.random()*500;
      enemyarray.push(new Enemy(xposition, yposition));
    }
  }
  function check(i) {
    playerX;
    playerY;
    p_j_distance=Math.sqrt(Math.pow((playerX+40)-(junglearray[i].x+35),2)+Math.pow((playerY+40)-(junglearray[i].y+35),2));
    if(p_j_distance < 40)
      return false;
    else {return true;}
  }
  var p_e_distance=0;
  let img_enemy = new Image();
  let moving;
  let sW=270;
  img_enemy.src="enemy.PNG";
  img_enemy.onload = function () {
    addEnemies(8);
    moving=setInterval(function(){
    for(var i=0;i<enemyarray.length;i++) {
     random = Math.random();
     if(random<0.25) {
       ctx.clearRect(enemyarray[i].x, enemyarray[i].y,70,70);
       enemyarray[i].x += xspeed;
       enemyarray[i].y += yspeed;
       if(enemyarray[i].x > 720)
         enemyarray[i].x -= xspeed;
       if(enemyarray[i].y > 600)
         enemyarray[i].y -= yspeed;
     }
     else if(random<0.5) {
       ctx.clearRect(enemyarray[i].x,enemyarray[i].y,70,70);
       enemyarray[i].x += xspeed;
       enemyarray[i].y -= yspeed;
       if(enemyarray[i].x > 720)
         enemyarray[i].x -= xspeed;
       if(enemyarray[i].y < 0)
         enemyarray[i].y += yspeed;
     }
     else if(random<0.75) {
       ctx.clearRect(enemyarray[i].x,enemyarray[i].y,70,70);
       enemyarray[i].x -= xspeed;
       enemyarray[i].y += yspeed;
       if(enemyarray[i].x < 0)
         enemyarray[i].x += xspeed;
       if(enemyarray[i].y > 600)
         enemyarray[i].y -= yspeed;
      }
     else {
       ctx.clearRect(enemyarray[i].x,enemyarray[i].y,70,70);
       enemyarray[i].x -= xspeed;
       enemyarray[i].y -= yspeed;
       if(enemyarray[i].x < 0)
         enemyarray[i].x += xspeed;
       if(enemyarray[i].y < 0)
         enemyarray[i].y += yspeed;
      }
     drawjungle(8);
     draw(enemyarray[i].x,enemyarray[i].y);
     p_j_distance=Math.sqrt(Math.pow((playerX+40)-(x_jungle+35),2)+Math.pow((playerY+40)-(y_jungle+35),2));
     p_e_distance=Math.sqrt(Math.pow((playerX+40)-(enemyarray[i].x+35),2)+Math.pow((playerY+40)-(enemyarray[i].y+35),2));
     if(p_e_distance < 100) {
       var result=true;
      for(var i=0;i<junglearray.length;i++) {
        result = result && check(i);
      }
      if(result) {
       gameover();
     }
     }
 }},300);
 }

  function draw(xposition,yposition) {
      ctx.clearRect(xposition,yposition,70,70);
      ctx.drawImage(img_enemy,sW,700,266,260,xposition,yposition,70,70,);
  }

  //Player
  var check_gameover=false;
  var img_player = new Image();
  var playerxspeed=20;
  var playeryspeed=20;
  var playerX=300;
  var playerY=10;
  var p_e_distance=0;
  img_player.src="player.PNG"
  img_player.onload=function () {
    ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
  }
  addEventListener("keydown", function(event) {
    if(event.keyCode == 38 && playerY > 0) {
      if(check_gameover) {
        playerY -= 0;
      }
      else {
      ctx.clearRect(playerX,playerY,80,80);
      playerY -= playeryspeed;
      drawjungle(8);
      ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
      }
    }
    if(playerX>250 && playerX<415 && playerY > 650) {
      wincondition();
    }
  })

  addEventListener("keydown", function(event) {
    if(event.keyCode == 40 && playerY < 720) {
      if(check_gameover) {
        playerY += 0;
      }
      else {
      ctx.clearRect(playerX,playerY,80,80);
      playerY += playeryspeed;
      drawjungle(8);
      ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
      }
    }
    if(playerX>250 && playerX<415 && playerY > 650) {
      wincondition();
    }
  })

  addEventListener("keydown", function(event) {
    if(event.keyCode == 39 && playerX < 720) {
      if(check_gameover) {
        playerX += 0;
      }
      else {
      ctx.clearRect(playerX,playerY,80,80);
      playerX += playerxspeed;
      drawjungle(8);
      ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
      }
    }
    if(playerX>250 && playerX<415 && playerY > 650) {
      wincondition();
    }
  })

  addEventListener("keydown", function(event) {
    if(event.keyCode == 37 && playerX > 0) {
      if(check_gameover) {
        playerX -= 0;
      }
      else {
      ctx.clearRect(playerX,playerY,80,80);
      playerX -= playerxspeed;
      drawjungle(8);
      ctx.drawImage(img_player,20,0,180,160,playerX,playerY,80,80);
      }
    }
    if(playerX>250 && playerX<415 && playerY > 650) {
      wincondition();
    }
  })
  function wincondition() {
    clearInterval(timer);
    clearInterval(moving);
    ctx.clearRect(xposition,yposition,80,80);
    ctx.clearRect(playerX,playerY,120,80);
    ctx.clearRect(710,5,80,40);

    ctx.clearRect(0,0,800,800);
    ctx.fillStyle="red";
    ctx.font = "italic 110px Arial";
    ctx.strokeStyle="black";
    ctx.lineWidth = 7;
    ctx.strokeText("YOU WIN!", 100, 380);
    ctx.fillText("YOU WIN!",100,380);
  }
  function gameover() {
    clearInterval(timer);
    clearInterval(moving);

    ctx.clearRect(0,0,800,800);
    ctx.fillStyle="red";
    ctx.font = "italic 110px Arial";
    ctx.strokeStyle="black";
    ctx.lineWidth = 7;
    ctx.strokeText("GAME OVER!", 70, 380);
    ctx.fillText("GAME OVER!",70,380);
    check_gameover=true;
  }
}
